//
//  Variable.swift
//  ValidateXMLXSD
//
//  Created by Friedrich HAEUPL on 21.09.18.
//  Copyright © 2018 Friedrich HAEUPL. All rights reserved.
//

import Cocoa

@objc class Variable: NSObject {
    @objc dynamic var name:String
    @objc dynamic var value:String
    @objc dynamic var isOptional:String
    
    override init() {
        name = "NameNAME"
        value = "01234567890"
        isOptional = "no"
    }
    
    init(name:String, value:String, isOptional:String) {
        self.name = name
        self.value = value
        self.isOptional = isOptional
        super.init()
    }
}
