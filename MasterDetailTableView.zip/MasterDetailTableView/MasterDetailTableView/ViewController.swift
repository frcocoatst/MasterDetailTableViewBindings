//
//  ViewController.swift
//  MasterDetailTableView
//
//  Created by Friedrich HAEUPL on 23.09.18.
//  Copyright © 2018 Friedrich HAEUPL. All rights reserved.
//

import Cocoa

var defaultsDict = ["@@Currency@@": "USD", "@@RequestedAmount@@": "10.00", "@@CashBackAmount@@": "1.00"]

var optionalDict = ["@@Currency@@": "no", "@@RequestedAmount@@": "no", "@@CashBackAmount@@": "yes"]



class ViewController: NSViewController {
    
    @objc dynamic var variables : [Variable] = [Variable]()

    @IBOutlet var arrayController: NSArrayController!
    
    @IBOutlet weak var tableView: NSTableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        variables.append(Variable(name: "First", value: "12.34", isOptional : "yes"))
        variables.append(Variable(name: "Second", value: "0.2", isOptional : "no"))
        variables.append(Variable(name: "Third", value: "0.8", isOptional : "maybe"))
        
        print("\(variables)")
        
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

